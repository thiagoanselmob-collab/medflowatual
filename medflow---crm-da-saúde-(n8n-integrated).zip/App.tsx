import React, { useState, useEffect } from 'react';
import { Login } from './pages/Login';
import { Sidebar } from './components/Sidebar';
import { CRM } from './pages/CRM';
import { Agenda } from './pages/Agenda';
import { Admin } from './pages/Admin';
import { User, UserRole, Doctor, Organization, AccountType } from './types';
import { authService, dataService } from './services/mockSupabase';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activePage, setActivePage] = useState('dashboard');
  const [loading, setLoading] = useState(true);

  // Global State for Multi-Doctor Context
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');
  const [organization, setOrganization] = useState<Organization | null>(null);

  useEffect(() => {
    // Check for existing session
    const storedUser = authService.getCurrentUser();
    if (storedUser) {
      setUser(storedUser);
    }
    setLoading(false);
  }, []);

  // Fetch Doctors and Organization when user logs in (if applicable)
  useEffect(() => {
    const loadDoctors = async () => {
        if (user && user.role !== UserRole.OWNER) {
            const org = await dataService.getOrganization(user.clinicId);
            setOrganization(org);
            
            const docs = await dataService.getDoctors(user.clinicId);
            setDoctors(docs);
            // Default to first doctor if none selected yet
            if (docs.length > 0 && !selectedDoctorId) {
                setSelectedDoctorId(docs[0].id);
            }
        }
    };
    loadDoctors();
  }, [user]);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    // Redirect based on role
    if (loggedInUser.role === UserRole.OWNER) {
      setActivePage('admin');
    } else {
      setActivePage('dashboard');
    }
  };

  const handleLogout = async () => {
    await authService.logout();
    setUser(null);
    setDoctors([]);
    setSelectedDoctorId('');
    setOrganization(null);
  };

  if (loading) {
    return <div className="h-screen w-screen flex items-center justify-center text-blue-600">Carregando MedFlow...</div>;
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-gray-50 text-gray-900 font-sans">
      <Sidebar 
        user={user} 
        activePage={activePage} 
        onNavigate={setActivePage}
        onLogout={handleLogout}
      />
      
      <main className="flex-1 ml-64 p-8 overflow-y-auto h-screen">
        <div className="max-w-7xl mx-auto h-full">
          {/* Routing Logic with Props Passing */}
          {activePage === 'dashboard' && (user.role !== UserRole.OWNER) && (
            <CRM 
                user={user} 
                doctors={doctors}
                selectedDoctorId={selectedDoctorId}
                onDoctorChange={setSelectedDoctorId}
                isConsultorio={organization?.accountType === AccountType.CONSULTORIO}
            />
          )}
          
          {activePage === 'agenda' && (user.role !== UserRole.OWNER) && (
            <Agenda 
                user={user} 
                doctors={doctors}
                selectedDoctorId={selectedDoctorId}
                onDoctorChange={setSelectedDoctorId}
                isConsultorio={organization?.accountType === AccountType.CONSULTORIO}
            />
          )}
          
          {activePage === 'admin' && (user.role !== UserRole.SECRETARY) && (
            <Admin currentUser={user} />
          )}
          
          {/* Fallback for Owner accessing CRM directly (forbidden usually, but handled here) */}
          {activePage === 'dashboard' && user.role === UserRole.OWNER && (
            <div className="text-center mt-20">
              <h3 className="text-xl font-bold">Acesso Restrito</h3>
              <p>O dono do sistema deve usar o painel administrativo.</p>
              <button onClick={() => setActivePage('admin')} className="mt-4 text-blue-600 underline">Ir para Admin</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;