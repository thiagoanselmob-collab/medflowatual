import React, { useState } from 'react';
import { authService } from '../services/mockSupabase';
import { User } from '../types';
import { ShieldCheck, User as UserIcon, Lock, Key, X, CheckCircle } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Password Recovery State
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);
  const [recoveryIdentifier, setRecoveryIdentifier] = useState('');
  const [recoveryStatus, setRecoveryStatus] = useState<'idle' | 'loading' | 'success'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const user = await authService.login(username, password);
      if (user) {
        onLogin(user);
      } else {
        setError('Credenciais inválidas. Verifique usuário e senha.');
      }
    } catch (err) {
      setError('Erro ao conectar ao servidor.');
    } finally {
      setLoading(false);
    }
  };

  const handleRecovery = async (e: React.FormEvent) => {
      e.preventDefault();
      setRecoveryStatus('loading');
      
      // Simulate N8N trigger
      await authService.recoverPassword(recoveryIdentifier);
      
      setRecoveryStatus('success');
      // Auto close after success
      setTimeout(() => {
          setIsRecoveryOpen(false);
          setRecoveryStatus('idle');
          setRecoveryIdentifier('');
      }, 3000);
  };

  const fillCredentials = (u: string, p: string) => {
    setUsername(u);
    setPassword(p);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4 font-sans">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 relative">
        <div className="bg-white p-8 pb-0 text-center">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-blue-200 transform -rotate-6">
            <ShieldCheck size={32} className="text-white transform rotate-6" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">MedFlow</h2>
          <p className="text-gray-500 mt-2 text-sm">CRM da Saúde & Automação</p>
        </div>
        
        <div className="p-8 pt-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Usuário</label>
              <div className="relative">
                <UserIcon size={18} className="absolute left-3 top-3.5 text-gray-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder-gray-400"
                  placeholder="Seu usuário"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Senha</label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-3.5 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder-gray-400"
                  placeholder="••••••"
                  required
                />
              </div>
            </div>

            <div className="flex justify-end">
                <button 
                    type="button" 
                    onClick={() => setIsRecoveryOpen(true)}
                    className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                >
                    Esqueceu a senha?
                </button>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100 flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-red-500 rounded-full"></div>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gray-900 hover:bg-black text-white font-semibold py-3.5 px-4 rounded-xl transition-all disabled:opacity-50 shadow-lg shadow-gray-200 hover:shadow-xl transform hover:-translate-y-0.5"
            >
              {loading ? 'Autenticando...' : 'Entrar no Sistema'}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-gray-100">
            <p className="text-xs text-center text-gray-400 mb-3">Acesso Rápido (Ambiente de Teste)</p>
            <div className="grid grid-cols-3 gap-2">
              <button 
                type="button"
                onClick={() => fillCredentials('admin', '123')}
                className="bg-white p-2 rounded-lg border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all text-xs text-gray-600 font-medium text-center group"
              >
                <span className="block text-purple-600 mb-1 group-hover:scale-110 transition-transform">👑</span>
                Dono
              </button>
              <button 
                type="button"
                onClick={() => fillCredentials('medico', '123')}
                className="bg-white p-2 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-all text-xs text-gray-600 font-medium text-center group"
              >
                <span className="block text-blue-600 mb-1 group-hover:scale-110 transition-transform">🩺</span>
                Médico
              </button>
              <button 
                type="button"
                onClick={() => fillCredentials('secretaria', '123')}
                className="bg-white p-2 rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-all text-xs text-gray-600 font-medium text-center group"
              >
                <span className="block text-green-600 mb-1 group-hover:scale-110 transition-transform">📅</span>
                Secretária
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Recovery Modal */}
      {isRecoveryOpen && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6 animate-in fade-in zoom-in-95">
                  {recoveryStatus === 'success' ? (
                      <div className="text-center py-4">
                          <CheckCircle size={48} className="text-green-500 mx-auto mb-3" />
                          <h3 className="text-lg font-bold text-gray-900">Solicitação Enviada!</h3>
                          <p className="text-sm text-gray-500 mt-2">
                              Se seus dados estiverem corretos, você receberá um link de recuperação via WhatsApp/Email em instantes.
                          </p>
                      </div>
                  ) : (
                    <form onSubmit={handleRecovery}>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold text-gray-900">Recuperar Acesso</h3>
                            <button type="button" onClick={() => setIsRecoveryOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={20}/></button>
                        </div>
                        <p className="text-sm text-gray-500 mb-4">
                            Digite seu usuário ou e-mail. Enviaremos um link seguro para você redefinir sua senha.
                        </p>
                        
                        <div className="mb-4">
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Usuário ou E-mail</label>
                            <div className="relative">
                                <Key size={18} className="absolute left-3 top-3 text-gray-400" />
                                <input 
                                    type="text" 
                                    required
                                    value={recoveryIdentifier}
                                    onChange={e => setRecoveryIdentifier(e.target.value)}
                                    className="w-full border border-gray-200 rounded-lg pl-10 pr-3 py-2.5 outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900"
                                    placeholder="Ex: doutor@medflow.com"
                                />
                            </div>
                        </div>

                        <button 
                            type="submit" 
                            disabled={recoveryStatus === 'loading'}
                            className="w-full bg-blue-600 text-white py-2.5 rounded-xl font-medium hover:bg-blue-700 transition-colors disabled:opacity-70"
                        >
                            {recoveryStatus === 'loading' ? 'Processando...' : 'Enviar Link de Recuperação'}
                        </button>
                    </form>
                  )}
              </div>
          </div>
      )}
    </div>
  );
};