
import React, { useEffect, useState } from 'react';
import { Appointment, AppointmentStatus, User, Column, Doctor } from '../types';
import { dataService } from '../services/mockSupabase';
import { Phone, User as UserIcon, Edit2, X, Lock, Save, Trash2, CalendarIcon, Stethoscope, FileText, ChevronDown } from 'lucide-react';
import { DatePicker } from '../components/DatePicker';

interface CRMProps {
  user: User;
  doctors: Doctor[];
  selectedDoctorId: string;
  onDoctorChange: (id: string) => void;
  isConsultorio?: boolean;
}

const COLUMNS: Column[] = [
  { id: AppointmentStatus.EM_CONTATO, title: 'Em Contato', color: 'bg-yellow-100 border-yellow-300' },
  { id: AppointmentStatus.AGENDADO, title: 'Agendados', color: 'bg-blue-100 border-blue-300' },
  { id: AppointmentStatus.ATENDIDO, title: 'Atendidos', color: 'bg-green-100 border-green-300' },
  { id: AppointmentStatus.NAO_VEIO, title: 'Não Veio', color: 'bg-red-100 border-red-300' },
];

export const CRM: React.FC<CRMProps> = ({ user, doctors, selectedDoctorId, onDoctorChange, isConsultorio }) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  
  const [loading, setLoading] = useState(true);
  const [draggedApptId, setDraggedApptId] = useState<string | null>(null);

  // Modal State
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  
  // Edit States for Modal
  const [editDate, setEditDate] = useState('');
  const [editTime, setEditTime] = useState('');
  const [editProcedure, setEditProcedure] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [procedureOptions, setProcedureOptions] = useState<string[]>([]);

  const [isDeleteConfirming, setIsDeleteConfirming] = useState(false);

  // 1. Fetch Procedure Options (dynamic per doctor)
  useEffect(() => {
    if (selectedDoctorId) {
        dataService.getProcedureOptions(user.clinicId, selectedDoctorId).then(setProcedureOptions);
    }
  }, [user.clinicId, selectedDoctorId]);

  // 2. Subscribe to Appointments (Real-time)
  useEffect(() => {
    if (!selectedDoctorId) return;
    setLoading(true);
    
    // Initial fetch to show data immediately
    dataService.getAppointments(user.clinicId, selectedDate, selectedDoctorId).then(data => {
        setAppointments(data);
        setLoading(false);
    });

    // Real-time Subscription
    const unsubscribe = dataService.subscribeToAppointments(
        user.clinicId, 
        selectedDate, 
        selectedDoctorId,
        (data) => {
            setAppointments(data);
            setLoading(false);
        }
    );

    return () => unsubscribe();
  }, [user.clinicId, selectedDate, selectedDoctorId]);

  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDraggedApptId(id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = async (e: React.DragEvent, targetStatus: AppointmentStatus) => {
    e.preventDefault();
    if (!draggedApptId) return;

    try {
      const appt = appointments.find(a => a.id === draggedApptId);
      if (appt && appt.status !== targetStatus) {
        
        // Optimistic UI Update
        setAppointments(prev => prev.map(a => 
            a.id === draggedApptId ? { ...a, status: targetStatus } : a
        ));

        // API Call
        await dataService.updateAppointmentStatus(draggedApptId, targetStatus);
        
        // Log N8N simulation
        if (targetStatus === AppointmentStatus.ATENDIDO) {
            console.log(`[N8N] Triggering Review Request for ${appt.patientName}`);
        } else if (targetStatus === AppointmentStatus.NAO_VEIO) {
            console.log(`[N8N] Triggering Recovery Flow for ${appt.patientName}`);
        }
      }
    } catch (error) {
      alert('Erro ao atualizar status.');
      // Revert optimistic update is handled by subscription refresh
    } finally {
      setDraggedApptId(null);
    }
  };

  const openDetails = (appt: Appointment) => {
    setSelectedAppointment(appt);
    setEditDate(appt.date);
    setEditTime(appt.time);
    setEditProcedure(appt.procedure || '');
    setEditNotes(appt.notes || '');
    setIsDeleteConfirming(false);
    setIsDetailsModalOpen(true);
  };

  const handleUpdateAppointment = async () => {
    if (!selectedAppointment) return;
    try {
      await dataService.updateAppointment({
        ...selectedAppointment,
        date: editDate,
        time: editTime,
        procedure: editProcedure,
        notes: editNotes
      });
      setIsDetailsModalOpen(false);
      alert("Alterações salvas!");
    } catch (error: any) {
      alert(error.message || "Erro ao salvar.");
    }
  };

  const handleDeleteAppointment = async () => {
      if (!selectedAppointment) return;
      try {
          await dataService.deleteAppointment(selectedAppointment.id);
          setIsDetailsModalOpen(false);
      } catch (e) { alert("Erro ao cancelar."); }
  };

  const generateTimeOptions30Min = () => {
      const options = [];
      for (let i = 0; i < 24; i++) {
        const h = String(i).padStart(2, '0');
        options.push(`${h}:00`);
        options.push(`${h}:30`);
      }
      return options;
  };

  const currentDoctorName = doctors.find(d => d.id === selectedDoctorId)?.name;

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Gestão de Pacientes (CRM)</h2>
          <p className="text-sm text-gray-500">Arraste os cards para mudar o status e disparar automações.</p>
        </div>
        
        <div className="flex items-center gap-3">
            {!isConsultorio ? (
                <div className="relative">
                    <UserIcon size={16} className="absolute left-2.5 top-2.5 text-gray-400" />
                    <select
                        value={selectedDoctorId}
                        onChange={(e) => onDoctorChange(e.target.value)}
                        className="pl-9 pr-8 py-2 bg-white border border-gray-200 rounded-lg text-sm font-semibold text-gray-700 outline-none focus:ring-2 focus:ring-blue-500 appearance-none min-w-[200px]"
                    >
                        {doctors.map(doc => (
                            <option key={doc.id} value={doc.id}>{doc.name}</option>
                        ))}
                    </select>
                    <ChevronDown size={14} className="absolute right-2.5 top-3.5 text-gray-400 pointer-events-none" />
                </div>
            ) : (
                <div className="flex items-center gap-2 text-gray-600 font-medium bg-white px-3 py-2 rounded-lg border border-gray-200 shadow-sm">
                    <UserIcon size={16} className="text-blue-600" />
                    {currentDoctorName || 'Meu Consultório'}
                </div>
            )}
            
            <DatePicker value={selectedDate} onChange={setSelectedDate} />
        </div>
      </div>

      <div className="flex-1 overflow-x-auto overflow-y-hidden pb-4">
        <div className="flex gap-6 h-full min-w-[1000px]">
          {COLUMNS.map(column => (
            <div 
                key={column.id} 
                className="flex-1 flex flex-col bg-gray-100/50 rounded-xl border border-gray-200"
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, column.id)}
            >
              <div className={`p-4 border-b border-gray-200 rounded-t-xl ${column.color.replace('bg-', 'bg-opacity-50 ')}`}>
                <div className="flex justify-between items-center">
                    <h3 className="font-bold text-gray-700">{column.title}</h3>
                    <span className="bg-white/50 text-gray-600 text-xs font-bold px-2 py-1 rounded-full">
                        {appointments.filter(a => a.status === column.id).length}
                    </span>
                </div>
              </div>

              <div className="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                {loading ? (
                    <div className="text-center text-gray-400 text-sm mt-10">Carregando...</div>
                ) : appointments.filter(a => a.status === column.id).length === 0 ? (
                    <div className="text-center text-gray-300 text-sm mt-10 italic">Vazio</div>
                ) : (
                    appointments
                        .filter(a => a.status === column.id)
                        .map(appt => (
                            <div
                                key={appt.id}
                                draggable
                                onDragStart={(e) => handleDragStart(e, appt.id)}
                                onClick={() => openDetails(appt)}
                                className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 cursor-move hover:shadow-md transition-all group active:scale-95 active:shadow-lg"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <span className="font-bold text-gray-800">{appt.time}</span>
                                    {appt.procedure && (
                                        <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded border border-gray-200 truncate max-w-[100px]">
                                            {appt.procedure}
                                        </span>
                                    )}
                                </div>
                                <div className="flex items-center gap-2 mb-1">
                                    <UserIcon size={14} className="text-gray-400" />
                                    <p className="font-medium text-gray-900 text-sm truncate">{appt.patientName}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Phone size={14} className="text-gray-400" />
                                    <p className="text-xs text-gray-500">{appt.patientPhone}</p>
                                </div>
                                {appt.notes && (
                                    <div className="mt-2 pt-2 border-t border-gray-50 text-[11px] text-gray-400 italic truncate">
                                        "{appt.notes}"
                                    </div>
                                )}
                            </div>
                        ))
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Details Modal (Same as Agenda) */}
      {isDetailsModalOpen && selectedAppointment && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-200">
                <div className="flex justify-between items-center mb-6">
                    <div className="flex items-center gap-3">
                        <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                            <Edit2 size={24} />
                        </div>
                        <div>
                            <h3 className="text-lg font-bold text-gray-800">Detalhes do Paciente</h3>
                            <p className="text-sm text-gray-500">Visualizar e editar dados</p>
                        </div>
                    </div>
                    <button onClick={() => setIsDetailsModalOpen(false)}><X size={20} /></button>
                </div>

                <div className="space-y-6 mb-6">
                    <div className="flex items-start gap-4">
                        <div className="bg-blue-50 p-2 rounded-lg text-blue-600 mt-1"><UserIcon size={20} /></div>
                        <div>
                            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Paciente</h4>
                            <p className="text-lg font-semibold text-gray-900">{selectedAppointment.patientName}</p>
                        </div>
                    </div>
                    <div className="flex items-start gap-4">
                        <div className="bg-green-50 p-2 rounded-lg text-green-600 mt-1"><Phone size={20} /></div>
                        <div>
                            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Contato</h4>
                            <p className="text-base text-gray-700 font-medium">{selectedAppointment.patientPhone}</p>
                        </div>
                    </div>

                    <div className="border-t border-gray-100 pt-6">
                         <p className="text-xs font-bold text-gray-400 uppercase mb-3 flex items-center gap-1">
                             <CalendarIcon size={12} /> Editar Agendamento
                         </p>
                         
                         <div className="grid grid-cols-2 gap-3 mb-4">
                             <div>
                                 <label className="block text-xs text-gray-500 mb-1">Data</label>
                                 <DatePicker value={editDate} onChange={setEditDate} />
                             </div>
                             <div>
                                 <label className="block text-xs text-gray-500 mb-1">Hora</label>
                                 <select 
                                     value={editTime}
                                     onChange={(e) => setEditTime(e.target.value)}
                                     className="w-full border border-gray-200 bg-white rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 h-[42px]"
                                 >
                                     {generateTimeOptions30Min().map((t) => (
                                         <option key={t} value={t}>{t}</option>
                                     ))}
                                 </select>
                             </div>
                         </div>
                         
                         <div className="space-y-4">
                             <div>
                                 <label className="block text-xs text-gray-500 mb-1">Procedimento</label>
                                 <div className="relative">
                                     <Stethoscope size={16} className="absolute left-3 top-3 text-gray-400 pointer-events-none" />
                                     <select
                                         value={editProcedure}
                                         onChange={e => setEditProcedure(e.target.value)}
                                         className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-9 pr-4 py-2 text-sm focus:ring-2 focus:ring-blue-100 outline-none"
                                     >
                                         <option value="" disabled>Selecione...</option>
                                         {procedureOptions.map(opt => (
                                             <option key={opt} value={opt}>{opt}</option>
                                         ))}
                                     </select>
                                 </div>
                             </div>
                             <div>
                                 <label className="block text-xs text-gray-500 mb-1">Observações</label>
                                 <textarea
                                     value={editNotes}
                                     onChange={e => setEditNotes(e.target.value)}
                                     className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-100 outline-none resize-none"
                                     rows={2}
                                     placeholder="Adicionar notas..."
                                 />
                             </div>
                         </div>
                    </div>
                </div>

                {isDeleteConfirming ? (
                   <div className="bg-red-50 p-4 rounded-xl border border-red-100 mb-0">
                      <p className="text-red-800 text-sm font-bold text-center mb-3">
                        Tem certeza que deseja cancelar este agendamento?
                      </p>
                      <div className="flex gap-3">
                        <button
                          onClick={() => setIsDeleteConfirming(false)}
                          className="flex-1 py-2 bg-white border border-red-200 text-red-600 rounded-lg text-sm font-medium hover:bg-red-50 transition-colors"
                        >
                          Não
                        </button>
                        <button
                          onClick={handleDeleteAppointment}
                          className="flex-1 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors shadow-sm"
                        >
                          Sim, Cancelar
                        </button>
                      </div>
                   </div>
                ) : (
                   <div className="flex gap-3">
                      <button
                        type="button"
                        onClick={() => setIsDeleteConfirming(true)}
                        className="flex-1 py-3 bg-white border border-red-200 text-red-600 hover:bg-red-50 rounded-xl font-medium transition-colors flex justify-center items-center gap-2 shadow-sm"
                      >
                        <Trash2 size={18} />
                        Cancelar
                      </button>
                      <button
                        type="button"
                        onClick={handleUpdateAppointment}
                        className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-md flex justify-center items-center gap-2"
                      >
                        <Save size={18} />
                        Salvar
                      </button>
                   </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};
