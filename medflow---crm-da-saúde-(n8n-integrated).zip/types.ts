
export enum UserRole {
  OWNER = 'OWNER',         
  DOCTOR_ADMIN = 'DOCTOR_ADMIN', 
  SECRETARY = 'SECRETARY'  
}

export enum AppointmentStatus {
  EM_CONTATO = 'EM_CONTATO', 
  AGENDADO = 'AGENDADO',     
  ATENDIDO = 'ATENDIDO',     
  NAO_VEIO = 'NAO_VEIO',     
  BLOQUEADO = 'BLOQUEADO'    
}

export enum AccountType {
  CONSULTORIO = 'CONSULTORIO', // 1 médico apenas
  CLINICA = 'CLINICA'          // Múltiplos médicos
}

// ----------------------------------------------------------------------
// ESTRUTURA MULTI-TENANCY E MULTI-DOCTOR
// ----------------------------------------------------------------------

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  role: UserRole;
  clinicId: string;
}

export interface Organization {
  id: string;
  accountType: AccountType;
  name: string;
  ownerUserId: string; 
  maxDoctors: number; // 1 para CONSULTORIO, 999 para CLINICA
}

export interface Doctor {
  id: string;
  organizationId: string; 
  name: string;
  specialty: string;
  color?: string; 
}

export interface AvailableSlot {
  id: string;
  doctorId: string;
  date: string; 
  time: string; 
  isBooked: boolean;
  appointmentId?: string; 
  appointment?: Appointment; 
}

// ----------------------------------------------------------------------
// TRANSAÇÕES E CONFIGURAÇÃO
// ----------------------------------------------------------------------

export interface Appointment {
  id: string;
  clinicId: string; 
  doctorId: string; 
  slotId?: string;  
  
  patientId: string;
  patientName: string; 
  patientPhone: string; 
  
  date: string; 
  time: string; 
  
  status: AppointmentStatus;
  procedure?: string; 
  notes?: string;     
  
  n8nProcessed?: boolean;
  createdAt?: string;
}

export interface AgendaConfig {
  clinicId: string;
  doctorId?: string; // Configuração específica por médico
  startHour: string; 
  endHour: string;   
  intervalMinutes: number; 
  availableProcedures: string[]; 
}

export interface ClinicSettings {
  clinicId: string;
  n8nWebhookUrl?: string;       
  evolutionInstanceName?: string; 
  evolutionApiKey?: string;       
}

export interface Session {
  id: string;
  userId: string;
  deviceInfo: string;
  lastActive: string;
}

// ----------------------------------------------------------------------
// INTEGRATION TYPES (N8N)
// ----------------------------------------------------------------------

export interface N8NWebhookPayload {
  event: 'STATUS_CHANGED' | 'APPOINTMENT_CREATED' | 'AGENDA_BLOCKED';
  data: {
    appointmentId?: string;
    doctorName?: string;
    patientName?: string;
    patientPhone?: string;
    reason?: string; 
    notes?: string;
    oldStatus?: string;
    newStatus?: string;
    date?: string;
    time?: string;
  };
  timestamp: string;
  clinicId: string; 
}

export interface Column {
  id: AppointmentStatus;
  title: string;
  color: string;
}