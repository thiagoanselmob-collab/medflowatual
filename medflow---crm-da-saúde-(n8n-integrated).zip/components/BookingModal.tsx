import React, { useState } from 'react';
import { X, Calendar, Clock, User, Phone, Stethoscope, FileText } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (name: string, phone: string, reason: string, notes: string) => void;
  date: string;
  time: string;
  availableProcedures: string[];
  isSubmitting: boolean;
}

export const BookingModal: React.FC<BookingModalProps> = ({ 
  isOpen, onClose, onConfirm, date, time, availableProcedures, isSubmitting 
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [reason, setReason] = useState(availableProcedures[0] || 'Consulta');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !reason.trim()) return;
    onConfirm(name, phone, reason, notes);
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [y, m, d] = dateStr.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    return dateObj.toLocaleDateString('pt-BR', { 
        weekday: 'short', 
        day: '2-digit', 
        month: 'short', 
        year: 'numeric' 
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6 transform transition-all scale-100 animate-in fade-in zoom-in duration-200 overflow-y-auto max-h-[90vh]">
        <div className="flex justify-between items-center border-b border-gray-100 pb-4 mb-4">
          <h2 className="text-xl font-bold text-gray-800">Novo Agendamento</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <div className="text-sm text-gray-600 space-y-2 mb-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
          <div className="flex items-center gap-2">
            <Calendar size={16} className="text-blue-600" />
            <span className="font-medium">Data:</span> 
            <span className="text-gray-800 capitalize">{formatDate(date)}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-blue-600" />
            <span className="font-medium">Horário:</span> 
            <span className="text-gray-800 font-bold">{time}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="name" className="block text-xs font-bold text-gray-500 uppercase mb-1">Nome Completo</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-white text-gray-900 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder-gray-400"
                  placeholder="Ex: João da Silva"
                />
              </div>
            </div>

            <div className="mb-4">
              <label htmlFor="phone" className="block text-xs font-bold text-gray-500 uppercase mb-1">WhatsApp / Telefone</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Phone className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="phone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-white text-gray-900 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder-gray-400"
                  placeholder="Ex: (11) 99999-9999"
                />
              </div>
            </div>

            <div className="mb-4">
              <label htmlFor="reason" className="block text-xs font-bold text-gray-500 uppercase mb-1">Tipo de Procedimento</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Stethoscope className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  id="reason"
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-white text-gray-900 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all appearance-none"
                >
                  <option value="" disabled>Selecione...</option>
                  {availableProcedures.map(proc => (
                    <option key={proc} value={proc}>{proc}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="notes" className="block text-xs font-bold text-gray-500 uppercase mb-1">Observações</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 top-3 flex items-start pl-3">
                  <FileText className="h-5 w-5 text-gray-400" />
                </div>
                <textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className="w-full pl-10 pr-4 py-2 bg-white text-gray-900 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder-gray-400 resize-none"
                  placeholder="Opcional..."
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-8 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium shadow-lg shadow-blue-500/20 transition-all disabled:opacity-70 disabled:cursor-not-allowed flex justify-center items-center"
                >
                  {isSubmitting ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                      'Confirmar'
                  )}
                </button>
            </div>
          </form>
        </div>
      </div>
  );
};